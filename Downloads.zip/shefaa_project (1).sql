-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 13, 2020 at 03:17 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shefaa_project`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `user_account_id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `probable_start_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `actual_end_time` timestamp NULL DEFAULT NULL,
  `appointment_status_id` int(11) NOT NULL,
  `appointment_taken_date` date NOT NULL,
  `app_booking_channel_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appointment_status`
--

CREATE TABLE `appointment_status` (
  `id` int(11) NOT NULL,
  `status` varchar(10) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `appointment_status`
--

INSERT INTO `appointment_status` (`id`, `status`) VALUES
(1, 'كشف'),
(2, 'إعاده');

-- --------------------------------------------------------

--
-- Table structure for table `app_booking_channel`
--

CREATE TABLE `app_booking_channel` (
  `id` int(11) NOT NULL,
  `app_booking_channel_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `client_account`
--

CREATE TABLE `client_account` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `contact_number` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `social_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_admin` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `client_account`
--

INSERT INTO `client_account` (`id`, `first_name`, `last_name`, `contact_number`, `email`, `pass`, `access_token`, `social_token`, `photo`, `created_at`, `updated_at`, `is_admin`) VALUES
(1, 'اسماء', 'شعيب', '1094873015', 's@gmail.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(2, 'اسماء ', 'البنا', '1198376520', 'sa@yahoo.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(3, 'الاء', 'مصطفي ', '1265498620', 'am@hotmail.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(4, 'اماني', 'احمد', '1098765432', 'aa@gmail.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(5, 'شيماء ', 'السعيد', '1089653528', 'sh@yahoo.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(6, 'سلوى', 'المهدى', '1256789439', 'sa@hotmail.com', '', NULL, NULL, NULL, '2020-08-12 20:42:12', '2020-08-12 20:42:12', NULL),
(7, 'aaaa', 'aaaa', '12345678907', 'shefaaproject@gmail.com', '2435465768798tyu', NULL, NULL, '1597267419FB_IMG_1583444247755.jpg', '2020-08-12 19:23:39', '2020-08-12 19:23:39', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `client_review`
--

CREATE TABLE `client_review` (
  `id` int(11) NOT NULL,
  `user_account_id` int(11) DEFAULT NULL,
  `doctor_id` int(11) DEFAULT NULL,
  `is_review_anonymous` tinyint(1) DEFAULT NULL,
  `wait_time_rating` int(11) DEFAULT NULL,
  `bedside_manner_rating` int(11) DEFAULT NULL,
  `overall_rating` int(11) DEFAULT NULL,
  `review` varchar(2000) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_doctor_recommended` tinyint(1) DEFAULT NULL,
  `review_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `professional_statement` varchar(4000) COLLATE utf8_unicode_ci NOT NULL,
  `practicing_from` date NOT NULL,
  `access_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `social_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `first_name`, `last_name`, `professional_statement`, `practicing_from`, `access_token`, `social_token`, `photo`, `email`) VALUES
(3, ' هانى ', 'خليل', 'استشاري الجلدية وتجميل البشره- الامراض التناسلية و الذكورةدكتور جلدية متخصص في امراض تناسلية، جراحة تجميل الوجه، امراض ذكورة، جلدية بالغين، تجميل وليزر، جلدية اطفال و جراحة تجميل العيون\r\n', '2015-01-01', NULL, NULL, NULL, '');

-- --------------------------------------------------------

--
-- Table structure for table `doctor_specialization`
--

CREATE TABLE `doctor_specialization` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `specialization_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `hospital_affiliation`
--

CREATE TABLE `hospital_affiliation` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `hospital_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `city` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `in_network_insurance`
--

CREATE TABLE `in_network_insurance` (
  `id` int(11) NOT NULL,
  `insurance_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `office_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE `offices` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `hospital_affiliation_id` int(11) DEFAULT NULL,
  `time_slot_per_client_in_min` int(11) NOT NULL,
  `first_consultation_fee` int(11) NOT NULL,
  `followup_consultation_fee` int(11) DEFAULT NULL,
  `street_address` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `zip` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office_doctor_availability`
--

CREATE TABLE `office_doctor_availability` (
  `id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `day_of_week` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `start_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `end_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_available` char(1) COLLATE utf8_unicode_ci NOT NULL,
  `reason_of_unavailability` varchar(500) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `office_services`
--

CREATE TABLE `office_services` (
  `id` int(11) NOT NULL,
  `office_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `qualifications`
--

CREATE TABLE `qualifications` (
  `id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `qualification_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `institute_name` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `procurement_year` date NOT NULL,
  `practicing_ cirtifacate _photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `discount_percentage` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `specializations`
--

CREATE TABLE `specializations` (
  `id` int(11) NOT NULL,
  `specialization_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `specializations`
--

INSERT INTO `specializations` (`id`, `specialization_name`) VALUES
(7, 'جلدية\'),
(8, 'اسنان'),
(9, 'نفسي\r\nا'),
(10, 'اطفال وحديثي الولادة'),
(11, 'مخ واعصاب'),
(12, 'عظام'),
(13, 'نساء وتوليد'),
(14, 'انف واذن وحنجرة'),
(15, '\r\nقلب واوعية دموية'),
(16, 'امراض دم'),
(17, 'اورام'),
(18, 'باطنة'),
(19, 'تخسيس وتغذية'),
(20, '\r\nجراحة اطفال'),
(21, 'جراحة أورام'),
(22, 'جراحة اوعية دموية'),
(23, 'جراحة تجميل'),
(24, 'جراحة سمنة ومناظير'),
(25, 'جراحة عامة'),
(26, 'جراحة عمود فقري'),
(27, 'جراحة قلب وصدر'),
(28, '\r\nجراحة مخ واعصاب'),
(29, 'علاج طبيعي واصابات ملاعب'),
(30, 'علاج الآلام'),
(31, 'طب تقويمي'),
(32, 'طب المسنين'),
(33, 'طب الأسرة\r\n'),
(34, 'صدر وجهاز تنفسي\r\n'),
(35, 'سمعيات'),
(36, 'سكر وغدد صماء\r\n'),
(37, 'روماتيزم'),
(38, 'ذكورة وعقم\r\n'),
(39, 'حقن مجهري واطفال انابيب\r\n'),
(40, 'جهاز هضمي ومناظير\r\n'),
(41, 'حساسية ومناعة\r\n'),
(42, 'كبد'),
(43, 'ممارسة عامة\r\n'),
(44, 'نطق وتخاطب\r\n'),
(45, 'معامل تحاليل\r\n'),
(46, 'كلى\r\n'),
(47, 'مسالك بولية\r\n'),
(48, 'مراكز أشعة\r\n');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Table_6_opd` (`office_id`),
  ADD KEY `Table_6_user_account` (`user_account_id`),
  ADD KEY `app_app_booking_channel` (`app_booking_channel_id`),
  ADD KEY `appointment_appointment_status` (`appointment_status_id`);

--
-- Indexes for table `appointment_status`
--
ALTER TABLE `appointment_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_booking_channel`
--
ALTER TABLE `app_booking_channel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_account`
--
ALTER TABLE `client_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_review`
--
ALTER TABLE `client_review`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_review_doctor` (`doctor_id`),
  ADD KEY `client_review_user_account` (`user_account_id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor_specialization`
--
ALTER TABLE `doctor_specialization`
  ADD PRIMARY KEY (`id`),
  ADD KEY `doctor_spec_spec` (`specialization_id`),
  ADD KEY `doctor_specialization_doctor` (`doctor_id`);

--
-- Indexes for table `hospital_affiliation`
--
ALTER TABLE `hospital_affiliation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hospital_affiliation_doctor` (`doctor_id`);

--
-- Indexes for table `in_network_insurance`
--
ALTER TABLE `in_network_insurance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `in_ntw_ins_out_patient_dept` (`office_id`);

--
-- Indexes for table `offices`
--
ALTER TABLE `offices`
  ADD PRIMARY KEY (`id`),
  ADD KEY `opd_doctor` (`doctor_id`),
  ADD KEY `opd_hospital_affiliation` (`hospital_affiliation_id`);

--
-- Indexes for table `office_doctor_availability`
--
ALTER TABLE `office_doctor_availability`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Table_10_opd` (`office_id`);

--
-- Indexes for table `office_services`
--
ALTER TABLE `office_services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `offices` (`office_id`),
  ADD KEY `services` (`service_id`);

--
-- Indexes for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `education_doctor` (`doctor_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `specializations`
--
ALTER TABLE `specializations`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment_status`
--
ALTER TABLE `appointment_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `app_booking_channel`
--
ALTER TABLE `app_booking_channel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_account`
--
ALTER TABLE `client_account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `client_review`
--
ALTER TABLE `client_review`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `doctor_specialization`
--
ALTER TABLE `doctor_specialization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `hospital_affiliation`
--
ALTER TABLE `hospital_affiliation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `in_network_insurance`
--
ALTER TABLE `in_network_insurance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offices`
--
ALTER TABLE `offices`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `office_doctor_availability`
--
ALTER TABLE `office_doctor_availability`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `office_services`
--
ALTER TABLE `office_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `qualifications`
--
ALTER TABLE `qualifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `specializations`
--
ALTER TABLE `specializations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `Table_6_opd` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`),
  ADD CONSTRAINT `Table_6_user_account` FOREIGN KEY (`user_account_id`) REFERENCES `client_account` (`id`),
  ADD CONSTRAINT `app_app_booking_channel` FOREIGN KEY (`app_booking_channel_id`) REFERENCES `app_booking_channel` (`id`),
  ADD CONSTRAINT `appointment_appointment_status` FOREIGN KEY (`appointment_status_id`) REFERENCES `appointment_status` (`id`);

--
-- Constraints for table `client_review`
--
ALTER TABLE `client_review`
  ADD CONSTRAINT `client_review_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `client_review_user_account` FOREIGN KEY (`user_account_id`) REFERENCES `client_account` (`id`);

--
-- Constraints for table `doctor_specialization`
--
ALTER TABLE `doctor_specialization`
  ADD CONSTRAINT `doctor_spec_spec` FOREIGN KEY (`specialization_id`) REFERENCES `specializations` (`id`),
  ADD CONSTRAINT `doctor_specialization_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);

--
-- Constraints for table `hospital_affiliation`
--
ALTER TABLE `hospital_affiliation`
  ADD CONSTRAINT `hospital_affiliation_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);

--
-- Constraints for table `in_network_insurance`
--
ALTER TABLE `in_network_insurance`
  ADD CONSTRAINT `in_ntw_ins_out_patient_dept` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`);

--
-- Constraints for table `offices`
--
ALTER TABLE `offices`
  ADD CONSTRAINT `opd_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`),
  ADD CONSTRAINT `opd_hospital_affiliation` FOREIGN KEY (`hospital_affiliation_id`) REFERENCES `hospital_affiliation` (`id`);

--
-- Constraints for table `office_doctor_availability`
--
ALTER TABLE `office_doctor_availability`
  ADD CONSTRAINT `Table_10_opd` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`);

--
-- Constraints for table `office_services`
--
ALTER TABLE `office_services`
  ADD CONSTRAINT `offices` FOREIGN KEY (`office_id`) REFERENCES `offices` (`id`),
  ADD CONSTRAINT `services` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`);

--
-- Constraints for table `qualifications`
--
ALTER TABLE `qualifications`
  ADD CONSTRAINT `education_doctor` FOREIGN KEY (`doctor_id`) REFERENCES `doctors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
