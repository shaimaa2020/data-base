-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 16, 2020 at 02:11 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.3.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shifaa`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointments`
--

CREATE TABLE `appointments` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `f_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `spec` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `qualif` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `professional_statement` text COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `social_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hospital_name` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `time_slot_per_client_in_min` int(11) DEFAULT NULL,
  `first_fee` int(11) NOT NULL,
  `followup_fee` int(11) DEFAULT NULL,
  `clinic_address` varchar(300) COLLATE utf8_unicode_ci NOT NULL,
  `clinic_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `clinic_day_of_week` varchar(400) COLLATE utf8_unicode_ci NOT NULL,
  `clinic_start_time` time NOT NULL,
  `clinic_end_time` time NOT NULL,
  `l_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `f_name`, `photo`, `email`, `password`, `phone`, `spec`, `qualif`, `professional_statement`, `access_token`, `social_token`, `hospital_name`, `time_slot_per_client_in_min`, `first_fee`, `followup_fee`, `clinic_address`, `clinic_name`, `clinic_day_of_week`, `clinic_start_time`, `clinic_end_time`, `l_name`) VALUES
(1, 'هاني', NULL, 'hany@gmail.com', '123', '01098754326', 'جلدية ', 'كلية الطب_جامعه عين شمس', 'استشاري الجلدية وتجميل البشره- الامراض التناسلية و الذكورةدكتور جلدية متخصص في امراض تناسلية، جراحة تجميل الوجه، امراض ذكورة، جلدية بالغين، تجميل وليزر، جلدية اطفال و جراحة تجميل العيون\r\n', NULL, NULL, 'مستشفي عين شمس التخصصي', 15, 200, NULL, 'طنطا شارع الاستاد', 'عياده دكتور هانى خليل', 'السبت والتلات', '11:00:00', '20:00:00', 'خليل'),
(2, 'هاني', NULL, 'hanykamal@gmail.com', '123456', '01132459875', ' سكر وغدد صماء', 'كلية الطب _جامعة اسكندرية', 'استشاري امراض الغدد الصماء والسكر ،زميل الكلية الملكية البريطانية للامراض الباطنية MRCP_UK ،ماجيستير امراض الغدد الصماء والباطنة _كلية الطب _جامعة اسكندرية ، تشخيص وعلاج امراض الغدد الدرقية ،تشخيص وعلاج امراض الغدة الكظرية وخلل وظائف الغدة النخامية،تشخيص وعلاج التاخر في البلوغ والنمو وخلل الدورة الشهرية ،تشخيص وعلاج امراض السمنه ،علاج امراض هشاشة العظام ونقص فيتامين د\r\n', NULL, NULL, 'مستشفي طنطا العام', 30, 100, 0, 'طنطا شارع النحاس', 'مركز دكتور هاني كمال ', 'الاحد والخمبس', '09:00:00', '16:00:00', 'كمال'),
(3, 'صلاح ', NULL, 'salh@gmail.com', '123456789', '01267439821', 'جلديه', 'كليه طب_ جامعه الازهر', 'أخصائي جراحة التجميل والحروق وتنسيق القوام ماجستير الجراحة والتجميل د.دكتوراه جراحة التجميل والليزر عضو الجمعية الدولية لجراحي التجميل عضو الجمعية المصرية لجراحة التجميل والإصلاح\r\n', NULL, NULL, 'مستشفي الازهر التخصصي', 10, 150, NULL, 'المنصوره شارع الجلاء', 'مركز دكتور صلاح عصام', 'الاثنين والاربعاء', '10:00:00', '21:00:00', 'عصام');

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` double DEFAULT NULL,
  `info` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `price` double NOT NULL,
  `offer` double DEFAULT NULL,
  `doctor_name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `doctor_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `name`, `price`, `offer`, `doctor_name`, `doctor_id`) VALUES
(1, 'تقويم شفاف', 3000, NULL, 'هاني كمال', NULL),
(2, 'حشو عصب', 450, 0, 'شيماء السعيد', NULL),
(3, 'حشو عادي', 250, 0, '', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `phone` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `access_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `social_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_admin` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointments`
--
ALTER TABLE `appointments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointments`
--
ALTER TABLE `appointments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
